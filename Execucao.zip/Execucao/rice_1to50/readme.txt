This dataset is a subset of Rice_Image_Dataset:
https://www.muratkoklu.com/datasets/
It contains only the images from 1 to 50.


